﻿using System;
using WebApplication1.Context;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace WebApplication1.Controllers
{
    public class StudentsController : Controller
    {
        //
        // GET: /Students/
        StudentDBEntities dbObj = new StudentDBEntities();

        public ActionResult Student(Student obj)
        {
            if (obj != null)
            {
                return View(obj);
            }
            else
            {
                return View();
            }
        }
        [HttpPost]
        public ActionResult AddStudent(Student obj)
        {
            if (ModelState.IsValid)
            {
                Student studentObj = new Student();
                Address addressObj = new Address();
                studentObj.StudentID = obj.StudentID;
                studentObj.Firstname = obj.Firstname;
                studentObj.Lastname = obj.Lastname;
                studentObj.Email = obj.Email;
                studentObj.Phone = obj.Phone;
                addressObj.StudentID = obj.StudentID;
                addressObj.Street = obj.Address.Street;
                addressObj.City = obj.Address.City;
                addressObj.State = obj.Address.State;
                addressObj.ZipCode = obj.Address.ZipCode;

                if(obj.StudentID == 0)
                {
                    dbObj.Addresses.Add(addressObj);
                    dbObj.Students.Add(studentObj);
                    dbObj.SaveChanges();
                }
                else
                {
                    dbObj.Entry(addressObj).State = EntityState.Modified;
                    dbObj.Entry(studentObj).State = EntityState.Modified;
                    dbObj.SaveChanges();
                }
            }
            ModelState.Clear();
            return View("Student");
        }


        public ActionResult StudentList()
        {
            var res = dbObj.Students.ToList();
            return View(res);
        }

        public ActionResult Delete(int id)
        {
            var res1 = dbObj.Students.Where(x => x.StudentID == id).First();
            var res2 = dbObj.Addresses.Where(x => x.StudentID == id).First();
            dbObj.Students.Remove(res1);
            dbObj.Addresses.Remove(res2);
            dbObj.SaveChanges();

            var list = dbObj.Students.ToList();

            return View("StudentList", list);
        }
	}
}